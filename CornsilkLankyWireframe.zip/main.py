# def nome (): 
#      n = 10
#        print(n)


# senha = int(input( "digiteuma senha"))













# contador =  10 
# while contador > 0: 
#    print (contador)
#    contador -= 1 
# print ("contagem")

# random aleatorio 
# import random
# numero = random.random()
# print(numero)




# import random 
# x=  random.randrange(20,30)
# print(x)



# import random 


# chute =  int(input("digite um numero"))
# numero =  random.randint(0,1)  

# while chute == numero:
#   print ("escolhas um numero entre 0, 10")
#   print(f)


# [10:34, 07/10/2023] +55 11 94011-3707: # len = comprimento (quantidade)

# nome_da_cidade = 'Guarulhos'
# comprimento = len(nome_da_cidade)
# print(comprimento)

# dia_da_semana = 'sabado'
# print(len(dia_da_semana))

# x = 4
# print(type(x))

# x = 'terra'
# dado = x
# print(type(dado))

# z = '45'
# n = float(z)
# print(int(z))
# print(n+5)

# cidade = 'Guarulhos'
# print(cidade, '\n')
# frag = list(cidade)
# print(frag)

# tr = tuple(frag)
# print(tr)

# numero = range(1,11,2)
# print(numero)

# n = range (1,3)
# print(n)

# lista = [1,6,812,0,45]
# soma = sum(lista)
# print('a soma de tudo é', soma)

# lista = [100,36,145,1]
# maxi = max(lista)
# print(maxi)

# lista = [100,36,145,1]
# mini = min(lista)
# print(mini)

# lista = [56,566,7878,15,1,0,89,10]
# organize = sorted(lista)
# print(org…
# [16:06, 07/10/2023] +55 11 94011-3707: # def saudacao():
#     print("Olá,")
#     print("Mundo!")

# for i in range(5):
#     if i < 3:
#         print("Menor que 3")
#     else:
#         print("Igual ou maior que 3")


# def funcao_principal():
#     # Bloco de código da função principal
#     variavel1 = 10
#     variavel2 = 20

#     if variavel1 < variavel2:
#         # Bloco de código do if
#         print("Variável 1 é menor que Variável 2")
#     else:
#         # Bloco de código do else
#         print("Variável 1 é maior ou igual a Variável 2")

#     for i in range(5):
#         # Bloco de código do loop for
#         print(f"Valor de i: {i}")

# n = 1
# while n <= 10:
#   print('Ola mundo')

# n = 1
# while n <= 10:
#   print(f'numero: {n}')
#   n = n + 1
  
# senha = input('Digite uma senha')
# while senha == '123456':
#   print('Pode acessar')
# else:
#   print('Acesso negado')

# senha = int(input('Digite uma senha'))
# while senha == 123456:
#   print('Pode acessar')
# else:
#   print('Acesso negado')

# contador = 10
# while contador > 0:
#   print("Número:", contador)
#   contador -= 1
#   print("contagem")


# import random
# aleatorio = random.randrange(10,30)
# print(f'Esse é o número aleatório \n:{aleatorio}')
# multiplicacao = aleatorio * 10
# print(f'Esse é o número aleatório multiplicado\n{multiplicacao} ')



# **Exercício 1: Contagem regressiva simples**
# Escreva um programa que exiba uma contagem regressiva de 10 a 1, e depois imprima "Fogo!".



# from math import radians


# contador = 10   
# while contador > 0: 
#   print("numero", contador)
#   contador -= 1 

# mensagem = ("fogo")
# print(mensagem)




# **Exercício 2: Soma de números pares**

# Peça ao usuário que insira um número inteiro positivo e, em seguida, calcule a soma de todos os números pares de 2 até o número inserido.



# numero  = int(input("digite um numero positivo:\n'))
# x= random.randint()
# print(x)






# **Exercício 3: Tabuada de multiplicação**

# Peça ao usuário para inserir um número inteiro e mostre a tabuada de multiplicação desse número de 1 a 10.

# Tabuada de multiplicação

numero=int(input("Qual tabuada voce quer saber? Digite um numero de 1 a 10.\n"))

print(" Tabuada do ",numero,":\n")
for i in range(1,11):
        print(numero," X ",i," = ",numero*i, "\n")


